import numpy as np
# Arbitrary comment, means nothing, just for testing

def intround(floatval):
        return int(np.round(floatval,0))