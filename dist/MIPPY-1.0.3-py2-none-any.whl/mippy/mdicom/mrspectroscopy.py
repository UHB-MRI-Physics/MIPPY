"""
Don't know yet whether this will stay part of the MIPPY core,
but for now, why not!
"""