import numpy as np

def intround(floatval):
	return int(np.round(floatval,0))